import { NextResponse } from 'next/server';
import { z } from 'zod';
import { syncInstruments, syncPrices } from '@/worker/sync';

export const maxDuration = 300;

const schema = z.object({
  kind: z.enum(['instruments', 'price-one']),
  insCode: z.string().trim().min(1).optional(),
});

export async function POST(req: Request) {
  try {
    const body = schema.parse(await req.json());

    if (body.kind === 'price-one') {
      if (!body.insCode) {
        return NextResponse.json({ ok: false, error: 'insCode is required' }, { status: 400 });
      }
      const result = await syncPrices({ insCode: body.insCode, mode: 'backfill' });
      return NextResponse.json({ ok: true, result });
    }

    const result = await syncInstruments();
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    return NextResponse.json({
      ok: false,
      error: error instanceof Error ? error.message : 'Invalid request',
    }, { status: 500 });
  }
}
