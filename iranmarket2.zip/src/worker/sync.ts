import { Prisma } from '@prisma/client';
import { prisma } from '../lib/prisma';
import { tsetmc } from '../tsetmc/client';

type Obj = Record<string, unknown>;
type SyncMode = 'backfill' | 'resume' | 'incremental';

const BATCH_SIZE = 250;
const DB_RETRIES = 4;

function log(message: string) {
  console.log(`[SYNC ${new Date().toISOString()}] ${message}`);
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function rowsOf(payload: unknown): Obj[] {
  if (Array.isArray(payload)) return payload as Obj[];
  if (payload && typeof payload === 'object') {
    const obj = payload as Obj;
    for (const key of ['closingPriceDaily', 'marketwatch', 'instrument', 'instruments', 'data', 'items']) {
      if (Array.isArray(obj[key])) return obj[key] as Obj[];
    }
  }
  return [];
}

function dateOf(value: unknown): Date | null {
  const s = String(value ?? '');
  if (!/^\d{8}$/.test(s)) return null;
  const date = new Date(Date.UTC(
    Number(s.slice(0, 4)),
    Number(s.slice(4, 6)) - 1,
    Number(s.slice(6, 8))
  ));
  return Number.isNaN(date.getTime()) ? null : date;
}

function toBigInt(value: unknown): bigint | null {
  if (value === null || value === undefined || value === '') return null;
  try { return BigInt(String(value)); } catch { return null; }
}

function marketWatchPath() {
  const params = new URLSearchParams({
    market: '0', industrialGroup: '', showTraded: 'false',
    withBestLimits: 'false', hEven: '0', RefID: '0',
  });
  for (let i = 0; i <= 8; i++) params.append(`paperTypes[${i}]`, String(i + 1));
  return `ClosingPrice/GetMarketWatch?${params.toString()}`;
}

export async function syncInstruments() {
  const run = await prisma.syncRun.create({ data: { kind: 'INSTRUMENTS', status: 'RUNNING' } });
  try {
    log('Fetching instruments from TSETMC...');
    const rows = rowsOf(await tsetmc.get<unknown>(marketWatchPath()));
    if (!rows.length) throw new Error('TSETMC marketwatch returned no instruments.');

    let processed = 0;
    let skipped = 0;
    for (const row of rows) {
      const insCode = String(row.insCode ?? '').trim();
      const symbol = String(row.lva ?? '').trim();
      const name = String(row.lvc ?? '').trim();
      if (!insCode || !symbol) { skipped++; continue; }

      await prisma.instrument.upsert({
        where: { insCode },
        create: { insCode, symbol, name: name || null },
        update: { symbol, name: name || undefined, lastSyncedAt: new Date() },
      });
      processed++;
      if (processed % 250 === 0) log(`Instrument records processed: ${processed}`);
    }

    await prisma.syncRun.update({
      where: { id: run.id },
      data: { status: 'SUCCESS', fetched: rows.length, inserted: processed,
        message: skipped ? `${skipped} skipped` : null, finishedAt: new Date() },
    });
    return { fetched: rows.length, processed, skipped };
  } catch (error) {
    await prisma.syncRun.update({
      where: { id: run.id },
      data: { status: 'FAILED', message: error instanceof Error ? error.message : String(error), finishedAt: new Date() },
    });
    throw error;
  }
}

async function createManyWithRetry(data: Array<{
  instrumentId: string; date: Date; open: bigint | null; high: bigint | null;
  low: bigint | null; close: bigint | null; last: bigint | null;
  volume: bigint | null; value: bigint | null; rawPayload: Prisma.InputJsonValue;
}>) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= DB_RETRIES; attempt++) {
    try {
      return await prisma.dailyPrice.createMany({ data, skipDuplicates: true });
    } catch (error) {
      lastError = error;
      const message = error instanceof Error ? error.message : String(error);
      log(`Database batch failed (attempt ${attempt}/${DB_RETRIES}): ${message}`);
      if (attempt < DB_RETRIES) await sleep(attempt * 2500);
    }
  }
  throw lastError instanceof Error ? lastError : new Error('Database batch failed');
}

export async function syncPrices(options: {
  insCode?: string;
  mode?: SyncMode;
  limit?: number;
} = {}) {
  const mode = options.mode ?? 'backfill';
  const where: Prisma.InstrumentWhereInput = options.insCode
    ? { insCode: options.insCode, isActive: true }
    : { isActive: true };

  if (mode === 'resume' && !options.insCode) {
    where.priceSyncStatus = { in: ['PENDING', 'FAILED', 'RUNNING'] };
  }

  const instruments = await prisma.instrument.findMany({
    where,
    orderBy: { symbol: 'asc' },
    ...(options.limit && options.limit > 0 ? { take: options.limit } : {}),
  });

  if (options.insCode && instruments.length === 0) {
    throw new Error(`Active instrument not found: ${options.insCode}`);
  }

  const run = await prisma.syncRun.create({
    data: { kind: `PRICES_${mode.toUpperCase()}`, status: 'RUNNING' },
  });

  let fetched = 0;
  let inserted = 0;
  let failed = 0;
  let completed = 0;
  const errors: string[] = [];

  log(`Price sync started. mode=${mode}, instruments=${instruments.length}`);

  try {
    for (const instrument of instruments) {
      const startedAt = Date.now();
      await prisma.instrument.update({
        where: { id: instrument.id },
        data: { priceSyncStatus: 'RUNNING', priceSyncLastAttempt: new Date(), priceSyncError: null },
      });

      try {
        log(`Fetching ${instrument.symbol} (${instrument.insCode})`);
        const payload = await tsetmc.get<unknown>(
          `ClosingPrice/GetClosingPriceDailyList/${instrument.insCode}/0`
        );
        const rows = rowsOf(payload);
        if (!rows.length) throw new Error('TSETMC returned an empty history.');

        fetched += rows.length;
        const records = new Map<string, {
          instrumentId: string; date: Date; open: bigint | null; high: bigint | null;
          low: bigint | null; close: bigint | null; last: bigint | null;
          volume: bigint | null; value: bigint | null; rawPayload: Prisma.InputJsonValue;
        }>();

        for (const row of rows) {
          const date = dateOf(row.dEven);
          if (!date) continue;
          records.set(date.toISOString(), {
            instrumentId: instrument.id, date,
            open: toBigInt(row.priceFirst), high: toBigInt(row.priceMax),
            low: toBigInt(row.priceMin), close: toBigInt(row.pClosing),
            last: toBigInt(row.pDrCotVal), volume: toBigInt(row.qTotTran5J),
            value: toBigInt(row.qTotCap),
            rawPayload: JSON.parse(JSON.stringify(row)) as Prisma.InputJsonValue,
          });
        }

        const allData = [...records.values()].sort((a, b) => a.date.getTime() - b.date.getTime());
        if (!allData.length) throw new Error('No valid dated records in TSETMC response.');

        let data = allData;
        if (mode === 'incremental') {
          const latest = await prisma.dailyPrice.findFirst({
            where: { instrumentId: instrument.id },
            orderBy: { date: 'desc' },
            select: { date: true },
          });
          if (latest) {
            const latestTime = latest.date.getTime();
            data = allData.filter((record) => record.date.getTime() >= latestTime);
          }
        }

        let addedForInstrument = 0;
        for (let i = 0; i < data.length; i += BATCH_SIZE) {
          const batch = data.slice(i, i + BATCH_SIZE);
          const result = await createManyWithRetry(batch);
          addedForInstrument += result.count;
          inserted += result.count;
          log(`${instrument.symbol}: batch ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(data.length / BATCH_SIZE)}, inserted=${result.count}`);
        }

        // Refresh the newest date in case TSETMC revised today's closing values.
        const newest = allData[allData.length - 1];
        await prisma.dailyPrice.upsert({
          where: { instrumentId_date: { instrumentId: instrument.id, date: newest.date } },
          create: newest,
          update: {
            open: newest.open, high: newest.high, low: newest.low,
            close: newest.close, last: newest.last, volume: newest.volume,
            value: newest.value, rawPayload: newest.rawPayload,
          },
        });

        await prisma.instrument.update({
          where: { id: instrument.id },
          data: {
            priceSyncStatus: 'SUCCESS',
            priceSyncLastSuccess: new Date(),
            priceSyncError: null,
            priceSyncRecordCount: await prisma.dailyPrice.count({ where: { instrumentId: instrument.id } }),
          },
        });

        completed++;
        log(`Completed ${instrument.symbol}: fetched=${rows.length}, new=${addedForInstrument}, elapsed=${((Date.now() - startedAt) / 1000).toFixed(1)}s`);
      } catch (error) {
        failed++;
        const message = error instanceof Error ? error.message : String(error);
        errors.push(`${instrument.symbol}: ${message}`);
        await prisma.instrument.update({
          where: { id: instrument.id },
          data: { priceSyncStatus: 'FAILED', priceSyncError: message.slice(0, 4000) },
        }).catch((updateError) => log(`Could not save failure status for ${instrument.symbol}: ${String(updateError)}`));
        log(`FAILED ${instrument.symbol}: ${message}`);
      }
    }

    const status = failed === 0 ? 'SUCCESS' : completed > 0 ? 'PARTIAL' : 'FAILED';
    await prisma.syncRun.update({
      where: { id: run.id },
      data: { status, fetched, inserted, message: errors.length ? errors.slice(0, 30).join('\n') : null, finishedAt: new Date() },
    });

    const result = { mode, instruments: instruments.length, completed, fetched, inserted, failed, errors: errors.slice(0, 30) };
    log(`Price sync finished: ${JSON.stringify(result)}`);
    return result;
  } catch (error) {
    await prisma.syncRun.update({
      where: { id: run.id },
      data: { status: 'FAILED', fetched, inserted, message: error instanceof Error ? error.message : String(error), finishedAt: new Date() },
    });
    throw error;
  }
}
