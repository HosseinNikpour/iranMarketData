# Iran Market Analyzer

## نصب و راه‌اندازی

```powershell
npm install
npx prisma generate
npx prisma db push
npm run dev
```

پس از تغییر Schema، `db push` را یک‌بار اجرا کنید تا ستون‌های وضعیت همگام‌سازی به جدول `Instrument` اضافه شوند.

## دریافت اطلاعات

همگام‌سازی نمادها:

```powershell
npm run sync:instruments
```

دریافت تاریخچه کامل (تمام نمادهای فعال):

```powershell
npm run sync:prices
```

برای تست محدود:

```powershell
npm run sync:prices -- --limit=10
```

برای یک نماد:

```powershell
npm run sync:prices -- --insCode=17617474823279712
```

ادامه پردازش نمادهای PENDING، FAILED یا RUNNING (مثلاً بعد از قطع‌شدن Worker):

```powershell
npm run sync:prices:resume
```

همگام‌سازی افزایشی:

```powershell
npm run sync:prices:incremental
```

نکته: endpoint تاریخچه TSETMC که در این نسخه استفاده می‌شود، همچنان کل تاریخچه نماد را برمی‌گرداند. حالت incremental فقط ذخیره‌سازی دیتابیس را به تاریخ آخرین رکورد موجود محدود می‌کند و فعلاً دریافت شبکه‌ای را incremental نمی‌کند.

## وضعیت هر نماد

فیلدهای زیر در `Instrument` نگهداری می‌شوند:
- `priceSyncStatus`: وضعیت PENDING / RUNNING / SUCCESS / FAILED
- `priceSyncLastAttempt`: زمان آخرین تلاش
- `priceSyncLastSuccess`: زمان آخرین موفقیت
- `priceSyncError`: آخرین خطا
- `priceSyncRecordCount`: تعداد رکوردهای قیمت موجود

Worker را در ترمینال مستقل اجرا کنید، نه از طریق درخواست طولانی HTTP. برای ادامه پس از توقف ناخواسته، دستور `npm run sync:prices:resume` را اجرا کنید.
