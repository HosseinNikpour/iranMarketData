import {syncInstruments,syncPrices} from './sync';
async function main(){const c=process.argv[2]||'all';if(c==='instruments'||c==='all')console.log('Instruments',await syncInstruments());if(c==='prices'||c==='all')console.log('Prices',await syncPrices());}
main().catch(e=>{console.error(e);process.exitCode=1;});
