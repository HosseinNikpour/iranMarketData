
import { prisma } from '../lib/prisma';
import { tsetmc } from '../tsetmc/client';

type Obj = Record<string, unknown>;

const BATCH_SIZE = 500;

function log(message: string) {
  console.log(`[SYNC ${new Date().toISOString()}] ${message}`);
}

function rowsOf(payload: unknown): Obj[] {
  if (Array.isArray(payload)) return payload as Obj[];

  if (payload && typeof payload === 'object') {
    const obj = payload as Obj[];

    for (const key of [
      'closingPriceDaily',
      'marketwatch',
      'instrument',
      'instruments',
      'data',
      'items',
    ]) {
      if (Array.isArray((obj as unknown as Obj)[key])) {
        return (obj as unknown as Obj)[key] as Obj[];
      }
    }
  }

  return [];
}

function dateOf(value: unknown): Date | null {
  const s = String(value ?? '');

  if (!/^\d{8}$/.test(s)) return null;

  const date = new Date(
    Date.UTC(
      Number(s.slice(0, 4)),
      Number(s.slice(4, 6)) - 1,
      Number(s.slice(6, 8))
    )
  );

  return Number.isNaN(date.getTime()) ? null : date;
}

function toBigInt(value: unknown): bigint | null {
  if (value === null || value === undefined || value === '') {
    return null;
  }

  try {
    return BigInt(String(value));
  } catch {
    return null;
  }
}

function marketWatchPath() {
  const params = new URLSearchParams({
    market: '0',
    industrialGroup: '',
    showTraded: 'false',
    withBestLimits: 'false',
    hEven: '0',
    RefID: '0',
  });

  for (let i = 0; i <= 8; i++) {
    params.append(`paperTypes[${i}]`, String(i + 1));
  }

  return `ClosingPrice/GetMarketWatch?${params.toString()}`;
}

export async function syncInstruments() {
  const run = await prisma.syncRun.create({
    data: {
      kind: 'INSTRUMENTS',
      status: 'RUNNING',
    },
  });

  try {
    log('Fetching instruments from TSETMC...');

    const payload = await tsetmc.get<unknown>(marketWatchPath());
    const rows = rowsOf(payload);

    if (!rows.length) {
      throw new Error('TSETMC marketwatch returned no instruments.');
    }

    let inserted = 0;
    let skipped = 0;

    for (const row of rows) {
      const insCode = String(row.insCode ?? '').trim();
      const symbol = String(row.lva ?? '').trim();
      const name = String(row.lvc ?? '').trim();

      if (!insCode || !symbol) {
        skipped++;
        continue;
      }

      await prisma.instrument.upsert({
        where: { insCode },
        create: {
          insCode,
          symbol,
          name: name || null,
        },
        update: {
          symbol,
          name: name || undefined,
          lastSyncedAt: new Date(),
        },
      });

      inserted++;

      if (inserted % 500 === 0) {
        log(`Instruments processed: ${inserted}`);
      }
    }

    await prisma.syncRun.update({
      where: { id: run.id },
      data: {
        status: 'SUCCESS',
        fetched: rows.length,
        inserted,
        message: skipped ? `${skipped} skipped` : null,
        finishedAt: new Date(),
      },
    });

    log(`Instrument sync completed. Processed: ${inserted}`);

    return { fetched: rows.length, inserted, skipped };
  } catch (error) {
    await prisma.syncRun.update({
      where: { id: run.id },
      data: {
        status: 'FAILED',
        message: error instanceof Error ? error.message : String(error),
        finishedAt: new Date(),
      },
    });

    throw error;
  }
}

export async function syncPrices(onlyInsCode?: string) {
  const instruments = await prisma.instrument.findMany({
    where: onlyInsCode
      ? { insCode: onlyInsCode }
      : { isActive: true },
    orderBy: { symbol: 'asc' },
  });

  if (onlyInsCode && instruments.length === 0) {
    throw new Error(`Instrument not found: ${onlyInsCode}`);
  }

  const run = await prisma.syncRun.create({
    data: {
      kind: 'PRICES',
      status: 'RUNNING',
    },
  });

  let fetched = 0;
  let inserted = 0;
  let failed = 0;

  const errors: string[] = [];

  try {
    log(`Starting price sync. Instruments: ${instruments.length}`);

    for (const instrument of instruments) {
      const startedAt = Date.now();

      try {
        log(`Fetching history: ${instrument.symbol} (${instrument.insCode})`);

        const payload = await tsetmc.get<unknown>(
          `ClosingPrice/GetClosingPriceDailyList/${instrument.insCode}/0`
        );

        const rows = rowsOf(payload);

        if (!rows.length) {
          failed++;
          errors.push(`${instrument.symbol}: empty response`);
          log(`No history returned for ${instrument.symbol}`);
          continue;
        }

        fetched += rows.length;

        const records = new Map<string, {
          instrumentId: string;
          date: Date;
          open: bigint | null;
          high: bigint | null;
          low: bigint | null;
          close: bigint | null;
          last: bigint | null;
          volume: bigint | null;
          value: bigint | null;
          rawPayload: object;
        }>();

        for (const row of rows) {
          const date = dateOf(row.dEven);
          if (!date) continue;

          records.set(date.toISOString(), {
            instrumentId: instrument.id,
            date,
            open: toBigInt(row.priceFirst),
            high: toBigInt(row.priceMax),
            low: toBigInt(row.priceMin),
            close: toBigInt(row.pClosing),
            last: toBigInt(row.pDrCotVal),
            volume: toBigInt(row.qTotTran5J),
            value: toBigInt(row.qTotCap),
            rawPayload: JSON.parse(JSON.stringify(row)) as object,
          });
        }

        const data = [...records.values()];

        if (!data.length) {
          failed++;
          errors.push(`${instrument.symbol}: no valid dated records`);
          log(`No valid dates for ${instrument.symbol}`);
          continue;
        }

        log(`${instrument.symbol}: fetched ${rows.length}, valid ${data.length}. Saving...`);

        let savedForInstrument = 0;

        for (let i = 0; i < data.length; i += BATCH_SIZE) {
          const batch = data.slice(i, i + BATCH_SIZE);

          const result = await prisma.dailyPrice.createMany({
            data: batch,
            skipDuplicates: true,
          });

          savedForInstrument += result.count;
          inserted += result.count;

          log(
            `${instrument.symbol}: batch ${Math.floor(i / BATCH_SIZE) + 1}, ` +
            `new rows ${result.count}, total new ${savedForInstrument}/${data.length}`
          );
        }

        log(
          `Completed ${instrument.symbol}. New rows: ${savedForInstrument}. ` +
          `Duration: ${((Date.now() - startedAt) / 1000).toFixed(1)}s`
        );
      } catch (error) {
        failed++;

        const message = error instanceof Error ? error.message : String(error);
        errors.push(`${instrument.symbol}: ${message}`);

        log(`FAILED ${instrument.symbol}: ${message}`);
        console.error(error);
      }
    }

    const status = failed === 0
      ? 'SUCCESS'
      : inserted > 0
        ? 'PARTIAL'
        : 'FAILED';

    await prisma.syncRun.update({
      where: { id: run.id },
      data: {
        status,
        fetched,
        inserted,
        message: errors.length ? errors.slice(0, 20).join('\n') : null,
        finishedAt: new Date(),
      },
    });

    log(
      `Price sync finished. Instruments: ${instruments.length}, ` +
      `fetched: ${fetched}, new rows: ${inserted}, failed: ${failed}`
    );

    return {
      instruments: instruments.length,
      fetched,
      inserted,
      failed,
      errors: errors.slice(0, 20),
    };
  } catch (error) {
    await prisma.syncRun.update({
      where: { id: run.id },
      data: {
        status: 'FAILED',
        fetched,
        inserted,
        message: error instanceof Error ? error.message : String(error),
        finishedAt: new Date(),
      },
    });

    throw error;
  }
}
