
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { syncInstruments, syncPrices } from '@/worker/sync';

export const maxDuration = 300;

const schema = z.object({
  kind: z.enum([
    'instruments',
    'prices',
    'all',
    'price-one',
  ]),
  insCode: z.string().trim().min(1).optional(),
});

export async function POST(req: Request) {
  try {
    const body = schema.parse(await req.json());

    const result: Record<string, unknown> = {};

    if (body.kind === 'price-one') {
      if (!body.insCode) {
        return NextResponse.json(
          { ok: false, error: 'insCode is required for price-one' },
          { status: 400 }
        );
      }

      result.prices = await syncPrices(body.insCode);
    }

    if (body.kind === 'instruments' || body.kind === 'all') {
      result.instruments = await syncInstruments();
    }

    if (body.kind === 'prices' || body.kind === 'all') {
      result.prices = await syncPrices();
    }

    return NextResponse.json({
      ok: true,
      result,
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error:
          error instanceof Error
            ? error.message
            : 'Invalid request',
      },
      { status: 500 }
    );
  }
}
