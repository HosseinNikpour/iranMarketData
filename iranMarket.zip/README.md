# Iran Market Analyzer

پروژه مستقل تحلیل بازار بورس ایران با Next.js، TypeScript، Prisma و Neon PostgreSQL.

## نصب و اجرا

```bash
npm install
cp .env.example .env
# مقادیر DATABASE_URL و DIRECT_URL را با connection string دیتابیس Neon پر کنید
npx prisma generate
npx prisma db push
npm run dev
```

در ویندوز PowerShell:

```powershell
Copy-Item .env.example .env
```

وب‌اپ روی http://localhost:3000 اجرا می‌شود.

## همگام‌سازی داده‌ها

از صفحه «مدیریت داده» یا دستورات زیر استفاده کنید:

```bash
npm run sync:instruments
npm run sync:prices
npm run sync:all
```

## نکات مهم و محدودیت‌های نسخه اول

- مسیرهای عمومی TSETMC و شکل JSON آن‌ها ممکن است تغییر کند. endpointهای این نسخه نقطه شروع adapter هستند و پیش از استفاده واقعی باید با پاسخ زنده آزمایش شوند. اگر پاسخ شناخته نشود، عملیات با خطای واضح ثبت می‌شود.
- قیمت خام ذخیره می‌شود. `adjustedClose` عمداً خالی است؛ تا پیاده‌سازی رویدادهای شرکتی و تعدیل سود نقدی/افزایش سرمایه، قیمت خام را تعدیل‌شده فرض نکنید.
- تاریخچه شاخص باید از endpoint معتبر شاخص دریافت و در `MarketIndex` و `IndexDailyPrice` ذخیره شود. فعلاً صفحه موج‌ها از داده شاخص ذخیره‌شده استفاده می‌کند و adapter شاخص هنوز به endpoint متصل نشده است.
- الگوریتم ZigZag ساده است. زمان تأیید pivot باید در بک‌تست رعایت شود تا look-ahead bias رخ ندهد.
- API همگام‌سازی در این starter بدون احراز هویت است؛ قبل از انتشار عمومی حتماً آن را محدود کنید. اجرای دریافت کامل قیمت‌ها روی serverless ممکن است timeout شود؛ worker/CLI را روی ماشین پایدار اجرا کنید.
- قبل از استفاده عملیاتی، `npm run typecheck` و `npm run build` را اجرا و endpointها را تست کنید.

## ساختار

- `src/app`: صفحات و API
- `src/components`: کنترل‌های رابط کاربری
- `src/lib`: اتصال دیتابیس و تحلیل
- `src/tsetmc`: کلاینت HTTP
- `src/worker`: همگام‌سازی و CLI
- `prisma/schema.prisma`: مدل‌های دیتابیس
